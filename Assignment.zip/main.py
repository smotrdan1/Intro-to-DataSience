import math
import numpy as np
import csv
import matplotlib.pyplot as plt
import xlrd as xlrd
from numpy.core._multiarray_umath import ndarray

A = np.asarray([[2, 1, 2], [1, -2, 1], [1, 2, 3,], [1, 1, 1]])  # init A
b = np.asarray([[6], [1], [5], [2]])  # init b
TransposeA = np.transpose(A)
Reverse = np.linalg.inv(np.matmul(TransposeA, A))  # reverse the output between (TranposeA * A )
x = np.matmul(Reverse, np.matmul(TransposeA, b))  # isolate x
print(x)  # 2(a)

approx = (A @ x) - b  # find the approx
norm = np.linalg.norm(approx)  # do norm
print(norm)  # 2(b)

z = np.asarray([[808, 0, 0, 0], [0, 1, 0, 0], [0, 0, 1, 0], [0, 0, 0, 1]])
result = np.linalg.inv(TransposeA @ z @ A) @ (TransposeA @ z @ b)
print(result)

lostValue = (A @ result) - b
print(lostValue)  # lost value < 0.001
print(np.linalg.norm(lostValue))  # the lost value









#4

Z = np.asarray([[5, 6, 7, 8], [1, 3, 5, 4], [1, 0.5, 4, 2], [3, 4, 3, 1]])
F = np.asarray([[0.57, 0.56, 0.8, 1], [1.5, 4, 6.7, 4.9], [0.2, 0.1, 1, 0.6], [11, 30, 26, 10]])
D = np.zeros((4, 4))
i = 0
j = 0
for index in Z:
    vector = F[i]
    index_T = np.transpose(index)
    iTi = index_T @ index
    iTi_rev = 1/iTi  # x is a int now
    zTf = index_T @ vector
    x = iTi_rev * zTf
    D[i][i] = x
    i = i + 1
    j = j + 1

print(D)
#5
workbook = xlrd.open_workbook("C://Users/smotr/PycharmProjects/pythonProject/newData2.xlsx")
sheet = workbook.sheet_by_index(0)
matrix = []  # excel to matrix in python
with open("newData.csv") as csvfile:
    reader = csv.reader(csvfile)
    for row in reader:
        matrix.append(row)
Matrix = np.transpose(np.asarray(matrix))
DataOfA = np.transpose(Matrix[3:6])
DataOfA = DataOfA[3:36]
DataOfA = DataOfA.astype('float')
DataOfB = np.transpose(Matrix[9:10])
DataOfB = DataOfB[3:36]
DataOfB = DataOfB.astype('float')
DataOfRestOfA = np.transpose(Matrix[3:6])
DataOfRestOfA = DataOfRestOfA[36:44]
DataOfRestOfA = DataOfRestOfA.astype('float')
DataOfRestOfB = np.transpose(Matrix[9:10])
DataOfRestOfB = DataOfRestOfB[36:44]
DataOfRestOfB = DataOfRestOfB.astype('float')
TransposeDataOfA = np.transpose(DataOfA)
Reverse = np.linalg.inv(np.matmul(TransposeDataOfA, DataOfA))
x = np.matmul(Reverse, np.matmul(TransposeDataOfA, DataOfB))
var1 = np.linalg.norm(DataOfRestOfB-(np.matmul(DataOfRestOfA, x)))
var2 = np.linalg.norm(DataOfRestOfB)
print((var1) / (var2))






plt.title('Cases in France of covid 19 - expectation vs reality')
plt.xlabel('Weeks')
plt.ylabel('Number of cases in weekly average')
pred = DataOfRestOfA @ x
x = np.arange(1, 7)
y = np.array([0.0]*6)
for i in range(6):
    y[i] = DataOfRestOfB[i][0]

yCheck = np.array([0.0]*6)
for i in range(6):
    yCheck[i] = pred[i][0]
plt.plot(x, y)
plt.plot(x, yCheck)
plt.legend(['reality', 'prediction'])
plt.show()